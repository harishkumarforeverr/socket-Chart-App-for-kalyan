const app = require("express")();


const port = process.env.PORT || 7077
const server = require("http").createServer(app);

const io = require("socket.io")(server, {
  cors: {
    origin: "*",
  },
});

console.log(`socket service is listening on port: ${port}`);
io.on("connection", (socket) => {
  socket.emit("connected", "Successfully connected to the test_socket");

  // emeiting the event to only one user who is listing to that event
  socket.on("hello-event", (payload) => {
    console.log("ddddddddddddd", payload)
    const { user, mail } = payload
    socket.emit("hello-event-listen", `hello user_name:${user}, email:${mail}`);

  });
  socket.on("callback-event", (a, b, cb) => {
    if (cb) {
      cb(`event-2 completed : ${parseInt(a) + parseInt(b)}`);
    }
  });
});

// app.listen(5000, () => console.log("server is active..."));

server.listen(port, () => {
  console.log("Server is listening at 7077...");
});
