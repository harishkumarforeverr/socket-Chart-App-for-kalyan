import "./App.css";

import { useState, useEffect } from "react";
import io from "socket.io-client";
import { nanoid } from "nanoid";

// no dotenv
const socket = io.connect("http://localhost:7077");

function App() {
  const [Mail, setMail] = useState("");
  const [login, setLogin] = useState(false)

  const sendChat = (e) => {
    if (Mail) {
      e.preventDefault();
      socket.emit("hello-event", { mail: Mail, user: "kalyan" });
      setLogin(true)
    }

  };
  const sendChatLogout = (e) => {
    if (Mail) {
      e.preventDefault();
      socket.emit("hello-event", { mail: Mail, user: "kalyan" });
      setLogin(false)
      setMail("")
    }

  }; 
  useEffect(() => {

    socket.on("hello-event-listen", (payload) => {
      console.log("hello-event-listen", payload);

    });

  }, [socket]);

  return (
    <div className="App">
      <header className="App-header">
        {
          !login
            ?
            <div >
              <h1>  Login page</h1>
              <form onSubmit={sendChat}>
                <h4>

                </h4>{" "}
                <input
                  type="text"
                  name="email"
                  placeholder="Email address"
                  value={Mail}
                  onChange={(e) => {
                    setMail(e.target.value);
                  }}
                />
                <button type="submit">submit</button>
              </form>
            </div> : <div>
              <h1>{Mail}</h1>
              <button onClick={sendChatLogout}>Logout</button>
            </div>}
      </header>
    </div>
  );
}

export default App;
